$(document).ready(function(){
    $('.materialboxed').materialbox();
  });